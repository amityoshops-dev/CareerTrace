@echo off
setlocal
title Install CareerTrace Pro
set "APP=%LOCALAPPDATA%\CareerTrace"
set "PYV="
for %%v in (3.12 3.11 3.10 3.13) do if not defined PYV py -%%v -c "import sys" >nul 2>nul && set "PYV=%%v"
if not defined PYV goto nopy
echo Installing CareerTrace Pro to %APP%
echo The first install takes a few minutes. Please wait...
robocopy "%~dp0app" "%APP%" /E /XD data exports /NFL /NDL /NJH /NJS /NP >nul
if not exist "%APP%\data" xcopy /E /I /Y /Q "%~dp0app\data" "%APP%\data" >nul
if not exist "%APP%\exports" xcopy /E /I /Y /Q "%~dp0app\exports" "%APP%\exports" >nul
if not exist "%APP%\.venv\Scripts\python.exe" py -%PYV% -m venv "%APP%\.venv"
set "VPY=%APP%\.venv\Scripts\python.exe"
"%VPY%" -m pip install -q --upgrade pip
if exist "%APP%\requirements.txt" "%VPY%" -m pip install -q -r "%APP%\requirements.txt"
"%VPY%" -m pip install -q fastapi uvicorn python-dotenv requests pypdf python-docx openpyxl langchain-google-genai langgraph
"%VPY%" -m pip install -q pywebview
powershell -NoProfile -ExecutionPolicy Bypass -File "%APP%\make_shortcut.ps1" "%APP%"
echo.
echo Done. A "CareerTrace Pro" icon is now on your Desktop and in the Start menu.
echo Opening it now...
start "" /D "%APP%" "%APP%\.venv\Scripts\pythonw.exe" desktop.py
timeout /t 5 >nul
exit /b 0
:nopy
echo Python 3 was not found. Install Python 3.12 from python.org (tick "Add Python to PATH"), then run this again.
pause
exit /b 1
