@echo off
set "APP=%LOCALAPPDATA%\CareerTrace"
echo This removes CareerTrace Pro, its shortcuts and ALL its data (keys, tracker, files).
set /p OK=Type YES to continue: 
if /i not "%OK%"=="YES" exit /b 0
del "%USERPROFILE%\Desktop\CareerTrace Pro.lnk" 2>nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\CareerTrace Pro.lnk" 2>nul
rmdir /s /q "%APP%"
echo Removed.
pause
