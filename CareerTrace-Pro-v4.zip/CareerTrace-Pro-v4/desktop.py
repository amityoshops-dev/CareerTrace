"""CareerTrace Pro desktop launcher: runs the server and opens it in its own window (falls back to your browser)."""
import os, sys, time, socket, threading, webbrowser, urllib.request
os.chdir(os.path.dirname(os.path.abspath(__file__)))
if sys.stdout is None or sys.stderr is None:  # started with pythonw (no console window): log to a file
    os.makedirs("data", exist_ok=True)
    _log = open(os.path.join("data", "app.log"), "a", buffering=1, encoding="utf-8")
    sys.stdout = sys.stdout or _log
    sys.stderr = sys.stderr or _log
os.environ["CT_AUTORUN"] = "1"
PORT = int(os.environ.get("PORT", "8000"))


def is_ours(p):
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{p}/api/pro/health", timeout=3)
        return True
    except Exception:
        return False


def port_busy(p):
    try:
        socket.create_connection(("127.0.0.1", p), timeout=1).close()
        return True
    except Exception:
        return False


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def serve(port):
    import uvicorn
    host = "0.0.0.0" if os.environ.get("CODESPACES") else "127.0.0.1"
    uvicorn.run("careertrace_ui:app", host=host, port=port, log_config=None)


def wait(port):
    for _ in range(180):
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/docs", timeout=2)
            return True
        except Exception:
            time.sleep(1)
    return False


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    load_dotenv(".env.pro")
    if is_ours(PORT):
        print("CareerTrace Pro is already running - opening it.")
    else:
        if port_busy(PORT):
            PORT = free_port()
        threading.Thread(target=serve, args=(PORT,), daemon=True).start()
        if not wait(PORT):
            print("Server did not start. See data/app.log")
            sys.exit(1)
    url = f"http://127.0.0.1:{PORT}/pro"
    print("CareerTrace Pro is running at", url)
    try:
        import webview
        webview.create_window("CareerTrace Pro", url, width=1440, height=920, min_size=(1000, 650))
        try:
            webview.start(private_mode=False)
        except TypeError:
            webview.start()
    except Exception as e:
        webbrowser.open(url)
        print(f"Opened in your browser (native window not available: {type(e).__name__}).")
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            pass
