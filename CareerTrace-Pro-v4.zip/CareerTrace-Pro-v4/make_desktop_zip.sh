#!/usr/bin/env bash
# Builds CareerTrace-Desktop.zip (a ready-to-install Windows app) from the working repo. Run from the repo root.
set -e
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
{ [ -f careertrace_ui.py ] && [ -f careertrace_pro.py ]; } || { echo "Run from the repo root after install.sh"; exit 1; }
PY=$(command -v python3 || command -v python)
OUT=CareerTrace-Desktop
rm -rf "$OUT" "$OUT.zip"; mkdir -p "$OUT/app"
cp careertrace_*.py "$OUT/app/"
cp "$HERE/desktop.py" "$HERE/make_shortcut.ps1" "$HERE/app.ico" "$OUT/app/"
cp "$HERE/careertrace_pro.py" "$OUT/app/careertrace_pro.py"
cp -r pro_static "$OUT/app/pro_static"
[ -f requirements.txt ] && cp requirements.txt "$OUT/app/"
[ -f .env ] && cp .env "$OUT/app/"
[ -f .env.pro ] && cp .env.pro "$OUT/app/"
for d in data exports; do [ -d "$d" ] && cp -r "$d" "$OUT/app/$d"; done
mkdir -p "$OUT/app/data" "$OUT/app/exports"
for f in *.docx; do [ -f "$f" ] && cp "$f" "$OUT/app/"; done
cp "$HERE/Install CareerTrace.bat" "$HERE/Uninstall CareerTrace.bat" "$OUT/"
for f in .gitignore; do for l in "CareerTrace-Desktop/" "CareerTrace-Desktop.zip"; do grep -qxF "$l" .gitignore 2>/dev/null || echo "$l" >> .gitignore; done; done
$PY - <<'P'
import zipfile, os
with zipfile.ZipFile("CareerTrace-Desktop.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for r, _, fs in os.walk("CareerTrace-Desktop"):
        for f in fs:
            p = os.path.join(r, f)
            z.write(p, p)
P
rm -rf "$OUT"
echo "Built CareerTrace-Desktop.zip (it contains your API keys - keep it private, never upload it to GitHub)."
echo "Next: right-click CareerTrace-Desktop.zip in the Explorer panel > Download, unzip it on your PC, double-click 'Install CareerTrace.bat'."
