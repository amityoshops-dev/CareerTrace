param($App)
$ws = New-Object -ComObject WScript.Shell
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $s = $ws.CreateShortcut((Join-Path $dir 'CareerTrace Pro.lnk'))
  $s.TargetPath = Join-Path $App '.venv\Scripts\pythonw.exe'
  $s.Arguments = 'desktop.py'
  $s.WorkingDirectory = $App
  $s.IconLocation = (Join-Path $App 'app.ico')
  $s.Description = 'CareerTrace Pro'
  $s.Save()
}
