(function(){
if(window.__proLoaded)return;window.__proLoaded=1;
var b=document.createElement("button");
b.textContent="\u26A1 Pro: Search \u00B7 Tracker \u00B7 Resume \u00B7 LinkedIn";
b.style.cssText="position:fixed;right:18px;bottom:18px;z-index:99999;background:#3b82f6;color:#fff;border:0;border-radius:24px;padding:12px 18px;font:600 14px system-ui;cursor:pointer;box-shadow:0 4px 18px rgba(0,0,0,.4)";
var o=document.createElement("div");
o.style.cssText="position:fixed;inset:0;z-index:100000;background:#0b1220;display:none";
var f=document.createElement("iframe");
f.style.cssText="width:100%;height:100%;border:0";
o.appendChild(f);
b.onclick=function(){if(!f.src)f.src="/pro";o.style.display="block"};
addEventListener("message",function(e){if(e.data==="pro-close")o.style.display="none"});
document.body.appendChild(b);document.body.appendChild(o);
})();
