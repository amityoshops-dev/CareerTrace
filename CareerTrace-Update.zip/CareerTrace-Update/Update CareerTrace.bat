@echo off
set "APP=%LOCALAPPDATA%\CareerTrace"
if not exist "%APP%\desktop.py" (
  echo CareerTrace is not installed at %APP%. Run "Install CareerTrace.bat" first.
  pause
  exit /b 1
)
copy /Y "%~dp0careertrace_pro.py" "%APP%\careertrace_pro.py" >nul
copy /Y "%~dp0pro_static\pro.html" "%APP%\pro_static\pro.html" >nul
echo Updated. Your keys, tracker and files are untouched.
echo Close CareerTrace Pro if it is open, then start it again from the desktop icon.
pause
